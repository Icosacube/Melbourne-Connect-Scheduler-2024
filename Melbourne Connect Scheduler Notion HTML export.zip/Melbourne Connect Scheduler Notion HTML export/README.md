# Melbourne Connect Scheduler
To view the pages of Melbourne Connect Scheduler Notion site. 
Please open the `index.html` and click `Melbourne Connect Scheduler Home Page` link in the `index.html`.

The underneath links are each individual pages of our Notion site